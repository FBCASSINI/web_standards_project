// JavaScript Document

    $(function(){
      $("#includedContent").load("components/1/component.html"); 
    });


 $(function(){
      $("#includedContent2").load("components/2/component2.html"); 
    });
	
	 $(function(){
      $("#includedContent3").load("components/3/component3.html"); 
    });
	
	$(function(){
      $("#includedContent4").load("components/4/component4.html"); 
    });
	
	$(function(){
      $("#includedContent5").load("components/5/component5.html"); 
    });